/*
    AtlasForum - WebRTC SESLİ ARAMA (Zil + Reddetme Tam Destek)
*/

import {
    getFirestore,
    doc,
    setDoc,
    onSnapshot,
    addDoc,
    collection
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

const db = getFirestore();
const auth = window._auth;

// WebRTC bağlantısı
let pc = new RTCPeerConnection();

// HTML elemanları
let remoteAudio = document.getElementById("remoteAudio");
let ringtone = document.getElementById("ringtone");

// LocalStorage’dan arama bilgileri al
let callID = localStorage.getItem("callRoom");
let targetName = localStorage.getItem("callTargetName");

// Aranan kişinin adı ekrana yaz
document.getElementById("callName").innerText = `${targetName} aranıyor...`;

// Kullanıcının mikrofonunu al
navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
    stream.getTracks().forEach(track => pc.addTrack(track, stream));
});

/*
    KARŞI TARAFTAN SES GELİNCE OYNAT
*/
pc.ontrack = (event) => {
    remoteAudio.srcObject = event.streams[0];
    stopRingtone(); // Bağlantı kurulunca zil durur
};

/*
    FIRESTORE REFERANSLARI
*/
const callRef = doc(db, "calls", callID);
const offerCandidates = collection(callRef, "offerCandidates");
const answerCandidates = collection(callRef, "answerCandidates");

/*
    ICE ADAYLARI göndermek
*/
pc.onicecandidate = (event) => {
    if (event.candidate) {
        addDoc(offerCandidates, event.candidate.toJSON());
    }
};

/*
    🔔 ZİL SESİ (Başlat / Durdur)
*/
function playRingtone() {
    ringtone.volume = 1.0;
    ringtone.play();
}

function stopRingtone() {
    ringtone.pause();
    ringtone.currentTime = 0;
}

/*
    OFFER oluştur (aramayı başlat)
*/
startCall();

async function startCall() {

    // Arama başlar → zil çalsın
    playRingtone();

    // Teklif oluştur
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    // Firestore’a gönder
    await setDoc(callRef, { offer }, { merge: true });

    /*
        Firestore’dan cevap (ANSWER) dinle
    */
    onSnapshot(callRef, (snap) => {
        const data = snap.data();

        // ★★★ Karşı taraf REDDETTİ ★★★
        if (data?.rejected === true) {
            stopRingtone();
            alert("Arama reddedildi.");
            pc.close();
            window.location.href = "../messages/messages.html";
            return;
        }

        // ★★★ Karşı taraf cevap verdi (ANSWER) ★★★
        if (!pc.currentRemoteDescription && data?.answer) {
            pc.setRemoteDescription(new RTCSessionDescription(data.answer));
            stopRingtone();
        }
    });

    /*
        Karşı tarafın ICE adaylarını dinle
    */
    onSnapshot(answerCandidates, (snap) => {
        snap.docChanges().forEach(change => {
            if (change.type === "added") {
                let candidate = new RTCIceCandidate(change.doc.data());
                pc.addIceCandidate(candidate);
            }
        });
    });
}

/*
    ❌ Aramayı REDDET
*/
window.rejectCall = async function () {
    stopRingtone();

    await setDoc(callRef, { rejected: true }, { merge: true });

    pc.close();
    window.location.href = "../messages/messages.html";
};

/*
    🔚 Aramayı NORMAL bitir
*/
window.endCall = function () {
    stopRingtone();
    pc.close();
    window.location.href = "../messages/messages.html";
};
