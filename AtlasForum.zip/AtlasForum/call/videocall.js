/*
    AtlasForum - GÖRÜNTÜLÜ ARAMA SİSTEMİ
    WebRTC + Firestore + Zil + Reddetme TAM DESTEK
*/

import {
    getFirestore,
    doc,
    setDoc,
    onSnapshot,
    addDoc,
    collection
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

const db = getFirestore();
const auth = window._auth;

// WebRTC PeerConnection
let pc = new RTCPeerConnection();

// HTML elementleri
let localVideo = document.getElementById("localVideo");
let remoteVideo = document.getElementById("remoteVideo");
let ringtone = document.getElementById("ringtone");

// Call bilgileri
let callID = localStorage.getItem("callRoom");
let targetName = localStorage.getItem("callTargetName");

// Ekranda aranan kişinin adı
document.getElementById("callName").innerText = `${targetName} aranıyor...`;

/*  
    1) Kamera + Mikrofon al
*/
navigator.mediaDevices.getUserMedia({ video: true, audio: true })
.then(stream => {

    localVideo.srcObject = stream;

    // Tüm trackleri WebRTC'ye ekle
    stream.getTracks().forEach(track => pc.addTrack(track, stream));

})
.catch(err => alert("Kamera veya mikrofona izin ver!"));

/*  
    2) KARŞIDAN GÖRÜNTÜ/Ses GELİNCE oynat
*/
pc.ontrack = (event) => {
    remoteVideo.srcObject = event.streams[0];
    stopRingtone();
};

/*
    3) FIRESTORE referansları
*/
const callRef = doc(db, "calls", callID);
const offerCandidates = collection(callRef, "offerCandidates");
const answerCandidates = collection(callRef, "answerCandidates");

/*
    4) ICE ADAYLARI gönder
*/
pc.onicecandidate = (event) => {
    if (event.candidate) {
        addDoc(offerCandidates, event.candidate.toJSON());
    }
};

/*
    🔔 ZİL SESİNİ YÖNET
*/
function playRingtone() {
    ringtone.volume = 0.9;
    ringtone.play();
}

function stopRingtone() {
    ringtone.pause();
    ringtone.currentTime = 0;
}

/*
    5) Aramayı başlat (OFFER)
*/
startVideoCall();

async function startVideoCall() {

    // Zil sesi çalsın
    playRingtone();

    // Teklif (offer) oluştur
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);

    // Firestore’a kaydet
    await setDoc(callRef, { offer }, { merge: true });

    /*
        6) CEVAP (ANSWER) dinle
    */
    onSnapshot(callRef, (snap) => {
        const data = snap.data();

        // ★★★ Karşı taraf reddettiyse
        if (data?.rejected === true) {
            stopRingtone();
            alert("Görüntülü arama reddedildi.");
            pc.close();
            window.location.href = "../messages/messages.html";
            return;
        }

        // ★★★ ANSWER geldiyse bağlantıyı kur
        if (!pc.currentRemoteDescription && data?.answer) {
            pc.setRemoteDescription(new RTCSessionDescription(data.answer));
            stopRingtone();
        }
    });

    /*
        7) ICE adaylarını dinle
    */
    onSnapshot(answerCandidates, (snap) => {
        snap.docChanges().forEach(change => {
            if (change.type === "added") {
                pc.addIceCandidate(new RTCIceCandidate(change.doc.data()));
            }
        });
    });
}

/*
    ❌ 8) ARAMAYI REDDET
*/
window.rejectVideoCall = async function () {
    stopRingtone();
    await setDoc(callRef, { rejected: true }, { merge: true });
    pc.close();
    window.location.href = "../messages/messages.html";
};

/*
    🔚 9) ARAMAYI NORMAL BİTİR
*/
window.endVideoCall = function () {
    stopRingtone();
    pc.close();
    window.location.href = "../messages/messages.html";
};
