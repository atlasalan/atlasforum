<script type="module">

    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-app.js";

    import { 
        getAuth,
        signInWithEmailAndPassword,
        createUserWithEmailAndPassword,
        GoogleAuthProvider,
        signInWithPopup,
        updateProfile
    } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-auth.js";

    import {
        getStorage,
        ref,
        uploadBytes,
        getDownloadURL
    } from "https://www.gstatic.com/firebasejs/10.13.1/firebase-storage.js";

    const firebaseConfig = {
      apiKey: "AIzaSyD3d-kOppO84leVDURIP1I78iuduHx0Bqw",
      authDomain: "atlasforum-8fb09.firebaseapp.com",
      projectId: "atlasforum-8fb09",
      storageBucket: "atlasforum-8fb09.firebasestorage.app",
      messagingSenderId: "482628343102",
      appId: "1:482628343102:web:7c73f552a85db14855086f"
    };

    const app = initializeApp(firebaseConfig);

    // Auth
    const auth = getAuth(app);
    const provider = new GoogleAuthProvider();

    // Storage
    const storage = getStorage(app);

    window._auth = auth;
    window._provider = provider;
    window._storage = storage;
    window._updateProfile = updateProfile;

    window._emailLogin = signInWithEmailAndPassword;
    window._emailRegister = createUserWithEmailAndPassword;
    window._googleLogin = signInWithPopup;

    window._uploadRef = ref;
    window._uploadBytes = uploadBytes;
    window._getDownloadURL = getDownloadURL;

</script>
