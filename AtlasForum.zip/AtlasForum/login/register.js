async function registerAccount() {
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const pass = document.getElementById("password").value;
    const photo = document.getElementById("photo").files[0];

    if (username.length < 2)
        return alert("Kullanıcı adı çok kısa!");

    if (!photo)
        return alert("Profil fotoğrafı seçmelisin!");

    // Önce hesap oluştur
    createUserWithEmailAndPassword(window._auth, email, pass)
        .then(async (userCred) => {

            const user = userCred.user;

            // Storage yolunu belirle
            const imgRef = window._uploadRef(window._storage, "pfp/" + user.uid + ".jpg");

            // Fotoğrafı yükle
            await window._uploadBytes(imgRef, photo);

            // Download linki al
            const photoURL = await window._getDownloadURL(imgRef);

            // Profil güncelle
            await window._updateProfile(user, {
                displayName: username,
                photoURL: photoURL
            });

            alert("Kayıt başarılı!");

            window.location.href = "login.html";
        })
        .catch(err => alert("Hata: " + err.message));
}
