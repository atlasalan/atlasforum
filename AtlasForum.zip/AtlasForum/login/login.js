function loginEmail() {
    const email = document.getElementById("email").value;
    const pass = document.getElementById("password").value;

    window._emailLogin(window._auth, email, pass)
        .then(() => {
            alert("Giriş başarılı!");
            window.location.href = "../forum/forum.html";
        })
        .catch(err => alert("Hata: " + err.message));
}

function loginGoogle() {
    window._googleLogin(window._auth, window._provider)
        .then(() => {
            alert("Google ile giriş başarılı!");
            window.location.href = "../forum/home.html";
        })
        .catch(err => alert("Hata: " + err.message));
}
