/*  
   PROFİL SİSTEMİ
   - Kullanıcı adı
   - Profil fotoğrafı
   - Bio (hakkımda)
   - Firestore + Storage
*/

// Firebase elemanları
import {
    doc,
    setDoc,
    getDoc,
    getFirestore
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

import {
    ref,
    uploadBytes,
    getDownloadURL
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-storage.js";

const db = getFirestore();
const auth = window._auth;
const storage = window._storage;

// Mevcut giriş yapan kullanıcı
let user = auth.currentUser;

// Sayfa yüklenince kullanıcıyı çek
window.onload = async () => {
    user = auth.currentUser;

    if (!user) {
        alert("Giriş gerekli!");
        window.location.href = "../login/login.html";
        return;
    }

    // Profil verilerini Firestore'dan çek
    const userRef = doc(db, "userProfiles", user.uid);
    const snap = await getDoc(userRef);

    if (snap.exists()) {
        const data = snap.data();

        document.getElementById("pfp").src = data.photoURL || user.photoURL;
        document.getElementById("username").value = data.username || user.displayName;
        document.getElementById("bio").value = data.bio || "";
    } else {
        // İlk kez profil açıyorsa
        document.getElementById("pfp").src = user.photoURL;
        document.getElementById("username").value = user.displayName || "";
    }
};


// PROFİL FOTOĞRAFI DEĞİŞTİR
async function changePhoto() {
    const file = document.getElementById("pfpInput").files[0];
    if (!file) return alert("Fotoğraf seçmedin!");

    const imgRef = ref(storage, "pfp/" + user.uid + ".jpg");

    await uploadBytes(imgRef, file);
    const url = await getDownloadURL(imgRef);

    document.getElementById("pfp").src = url;

    alert("Fotoğraf güncellendi!");
}


// PROFİLİ KAYDET
async function saveProfile() {
    const username = document.getElementById("username").value;
    const bio = document.getElementById("bio").value;
    const photoURL = document.getElementById("pfp").src;

    await setDoc(doc(db, "userProfiles", user.uid), {
        username: username,
        bio: bio,
        photoURL: photoURL
    });

    alert("Profil kaydedildi!");
}
