/*  
    AtlasForum - Firestore Gerçek Zamanlı Mesajlaşma
*/

import {
    getFirestore,
    doc,
    setDoc,
    addDoc,
    collection,
    onSnapshot,
    serverTimestamp,
    query,
    orderBy
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

const db = getFirestore();
const auth = window._auth;

// Giriş yapan kullanıcı
let user = null;

// Aktif chat ettiği kullanıcı
let activeChat = null;

// Sayfa açılınca kullanıcıyı al
auth.onAuthStateChanged((u) => {
    if (!u) return;
    user = u;
});

// Sohbet aç
function openChatRT(username, uid) {
    activeChat = { username, uid };

    document.getElementById("chatHeader").innerText = username;

    loadMessagesRT(uid);
}

// Mesajları gerçek zamanlı dinle
function loadMessagesRT(uid) {
    const roomID = getRoomID(user.uid, uid);
    const msgRef = collection(db, "messages", roomID, "chats");

    const q = query(msgRef, orderBy("time", "asc"));

    onSnapshot(q, (snap) => {
        let box = document.getElementById("chatMessages");
        box.innerHTML = "";

        snap.forEach((doc) => {
            let msg = doc.data();

            box.innerHTML += `
                <div class="chat-bubble ${msg.uid === user.uid ? 'me' : 'other'}">
                    ${msg.avatar ? `<img src="${msg.avatar}" class="avatar">` : ""}
                    <div class="text">${msg.text}</div>
                    <div class="time">${formatTime(msg.time)}</div>
                </div>
            `;
        });

        box.scrollTop = box.scrollHeight;
    });
}

// Mesaj gönder
async function sendMessageRT() {
    if (!activeChat) return alert("Bir kullanıcı seç!");

    let input = document.getElementById("chatInput");
    if (input.value.trim() === "") return;

    const roomID = getRoomID(user.uid, activeChat.uid);

    const msgRef = collection(db, "messages", roomID, "chats");

    await addDoc(msgRef, {
        text: input.value,
        uid: user.uid,
        username: user.displayName,
        avatar: user.photoURL || "",
        time: serverTimestamp()
    });

    input.value = "";
}

// İki kullanıcının aynı odaya girişi için ortak ID üretir
function getRoomID(uid1, uid2) {
    return [uid1, uid2].sort().join("_");
}

// Firebase timestamp → saat formatına çevir
function formatTime(ts) {
    if (!ts) return "";
    const date = ts.toDate();
    return date.getHours().toString().padStart(2, "0") + ":" +
           date.getMinutes().toString().padStart(2, "0");
}

// Global fonksiyonlara bağla
window.openChatRT = openChatRT;
window.sendMessageRT = sendMessageRT;
