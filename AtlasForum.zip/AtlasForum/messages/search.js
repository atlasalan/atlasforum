/*
    KULLANICI ARAMA SİSTEMİ
    Firestore → userProfiles koleksiyonundan çekme
*/

import {
    getFirestore,
    collection,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

const db = getFirestore();

// Tüm kullanıcılar burada tutulacak
let allUsers = [];

// Sayfa yüklenince Firestore’dan kullanıcıları çek
window.onload = function () {
    listenUsers();
};

// Firestore’dan kullanıcıları anlık çek
function listenUsers() {
    const ref = collection(db, "userProfiles");

    onSnapshot(ref, (snap) => {
        allUsers = [];

        snap.forEach(doc => {
            allUsers.push({
                uid: doc.id,
                ...doc.data()
            });
        });

        renderUsers(allUsers);
    });
}

// Kullanıcıları listele
function renderUsers(list) {
    let area = document.getElementById("userList");
    area.innerHTML = "";

    if (list.length === 0) {
        area.innerHTML = `<p style="color:#777;">Kullanıcı bulunamadı.</p>`;
        return;
    }

    list.forEach(u => {
        area.innerHTML += `
            <div class="chat-user" onclick="openChatRT('${u.username}','${u.uid}')">
                <img src="${u.photoURL}" class="avatar-list">
                ${u.username}
            </div>
        `;
    });
}

// Arama kutusu bu fonksiyonu tetikler
function searchUser() {
    let q = document.getElementById("searchInput").value.toLowerCase();

    let filtered = allUsers.filter(u =>
        u.username.toLowerCase().includes(q)
    );

    renderUsers(filtered);
}

// Global
window.searchUser = searchUser;
