/*  
    WHATSAPP TARZI MESAJ SİSTEMİ
    AtlasForum - messages.js
    Sıfırdan yazılmış temiz sürüm
*/

// Test amaçlı kullanıcı listesi (ileride Firestore'a bağlanacak)
let users = ["Atlas", "Mehmet", "Ayşe", "Xenon", "Admin"];

// Aktif chat yapılan kullanıcı
let activeChatUser = null;

// Giriş yapan kullanıcı bilgisi (Auth'tan çekilecek)
let currentUser = {
    displayName: "Ben",
    photoURL: ""
};

// SAYFA YÜKLENİNCE ÇALIŞIR
window.onload = () => {
    loadUserList();
    loadAuthUser();
};


// Kullanıcı listesi yükle (sol kısım)
function loadUserList() {
    let listArea = document.getElementById("userList");
    listArea.innerHTML = "";

    users.forEach(username => {
        listArea.innerHTML += `
            <div class="chat-user" onclick="openChat('${username}')">
                ${username}
            </div>
        `;
    });
}


// Giriş yapan kullanıcının adını ve fotoğrafını almak
function loadAuthUser() {
    let saved = localStorage.getItem("authUser");
    if (saved) {
        let u = JSON.parse(saved);
        currentUser.displayName = u.displayName || "Ben";
        currentUser.photoURL = u.photoURL || "";
    }
}


// Bir kullanıcıya tıklanınca o sohbet açılır
function openChat(username) {
    activeChatUser = username;

    document.getElementById("chatHeader").innerText = username;

    loadMessages();
}


// Mesajları yükle
function loadMessages() {
    let key = "chat_" + activeChatUser;

    let messages = JSON.parse(localStorage.getItem(key) || "[]");

    let msgArea = document.getElementById("chatMessages");
    msgArea.innerHTML = "";

    if (messages.length === 0) {
        msgArea.innerHTML = `
            <p style="color:#777;">Bu kullanıcıyla henüz mesaj yok.</p>
        `;
        return;
    }

    messages.forEach(msg => {
        msgArea.innerHTML += `
            <div class="chat-bubble ${msg.sender === currentUser.displayName ? 'me' : 'other'}">
                ${msg.avatar ? `<img src="${msg.avatar}" class="avatar">` : ""}
                <div class="text">${msg.text}</div>
                <div class="time">${msg.time}</div>
            </div>
        `;
    });

    msgArea.scrollTop = msgArea.scrollHeight; // otomatik aşağı kaydır
}


// Mesaj gönder
function sendMessage() {
    if (!activeChatUser) return alert("Bir kullanıcı seç!");

    let input = document.getElementById("chatInput");
    let text = input.value.trim();

    if (text === "") return;

    let key = "chat_" + activeChatUser;
    let messages = JSON.parse(localStorage.getItem(key) || "[]");

    // Saat hesaplama
    let now = new Date();
    let hh = now.getHours().toString().padStart(2, "0");
    let mm = now.getMinutes().toString().padStart(2, "0");

    // Mesajı ekle
    messages.push({
        sender: currentUser.displayName,
        avatar: currentUser.photoURL,
        text: text,
        time: hh + ":" + mm
    });

    // Kaydet
    localStorage.setItem(key, JSON.stringify(messages));

    input.value = "";
    loadMessages();
}
