/*/*
   ÇEVRİMİÇİ / SON GÖRÜLME SİSTEMİ
*/

import {
    doc,
    setDoc,
    serverTimestamp,
    getFirestore
} from "https://www.gstatic.com/firebasejs/10.13.1/firebase-firestore.js";

const db = getFirestore();
const auth = window._auth;

let user = null;

// Kullanıcı oturum değişimini dinle
auth.onAuthStateChanged(async (u) => {
    if (!u) return;
    user = u;

    // Kullanıcıyı online yap
    await setDoc(doc(db, "presence", user.uid), {
        online: true,
        lastSeen: serverTimestamp()
    }, { merge: true });

    // Sayfa kapanınca offline yap
    window.addEventListener("beforeunload", async () => {
        await setDoc(doc(db, "presence", user.uid), {
            online: false,
            lastSeen: serverTimestamp()
        }, { merge: true });
    });
});

