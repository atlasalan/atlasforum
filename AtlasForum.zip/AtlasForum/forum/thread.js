// Konu ID'yi al
let topicId = localStorage.getItem("openTopicId");

// Tüm konuları çek
let topics = JSON.parse(localStorage.getItem("topics") || "[]");
let topic = topics[topicId];

// Sayfa açılır açılmaz konuyu göster
window.onload = function () {
    if (!topic) {
        alert("Konu bulunamadı!");
        window.location.href = "forum.html";
        return;
    }

    document.getElementById("topicTitle").innerText = topic.title;
    document.getElementById("topicContent").innerText = topic.content;

    loadMessages();
};

// Mesajları yükle
function loadMessages() {
    let messageList = document.getElementById("messageList");

    // Mesaj yoksa
    if (!topic.messages || topic.messages.length === 0) {
        messageList.innerHTML = `<p style="color:#777;">Bu konuda henüz mesaj yok.</p>`;
        return;
    }

    messageList.innerHTML = "";

    topic.messages.forEach(m => {
        messageList.innerHTML += `
            <div class="message">
                <div class="message-author">${m.author}</div>
                <div class="message-text">${m.text}</div>
            </div>
        `;
    });
}

// Mesaj gönder
function sendMessage() {
    let text = document.getElementById("newMessage").value;

    if (text.length < 1) return alert("Mesaj boş olamaz!");

    // Mesaj listesi yoksa oluştur
    if (!topic.messages) topic.messages = [];

    // Mesajı ekle
    topic.messages.push({
        author: "Anonim Kullanıcı", // Firebase'e geçince buraya kullanıcı adı gelecek
        text: text
    });

    // LocalStorage güncelle
    topics[topicId] = topic;
    localStorage.setItem("topics", JSON.stringify(topics));

    document.getElementById("newMessage").value = "";

    loadMessages();
}
