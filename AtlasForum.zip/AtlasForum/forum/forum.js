// Konuları localStorage'dan çek
function loadTopics() {
    let topics = JSON.parse(localStorage.getItem("topics") || "[]");

    let list = document.getElementById("topicList");

    if (topics.length === 0) {
        list.innerHTML = `<p style="color:#888;">Henüz hiç konu açılmamış.</p>`;
        return;
    }

    list.innerHTML = "";

    topics.forEach((t, i) => {
        list.innerHTML += `
            <div class="topic-item" onclick="openTopic(${i})">
                <h3>${t.title}</h3>
                <p>${t.preview}</p>
            </div>
        `;
    });
}

// Yeni konu oluştur
function createTopic() {
    let title = document.getElementById("topicTitle").value;
    let content = document.getElementById("topicContent").value;

    if (title.length < 3) return alert("Başlık çok kısa!");
    if (content.length < 5) return alert("İçerik çok kısa!");

    let topics = JSON.parse(localStorage.getItem("topics") || "[]");

    topics.push({
        title: title,
        content: content,
        preview: content.substring(0, 80) + "..."
    });

    localStorage.setItem("topics", JSON.stringify(topics));

    alert("Konu oluşturuldu!");
    loadTopics();
}

// Konu aç
function openTopic(id) {
    localStorage.setItem("openTopicId", id);
    window.location.href = "thread.html";
}

// Sayfa açıldığında konuları yükle
window.onload = loadTopics;
